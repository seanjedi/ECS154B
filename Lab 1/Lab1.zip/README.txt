Name: Sean Malloy
Difficulties: I wasn't able to figure out how to do testing for my circuit, in particular I wasn't able to figure out how to do the logging and making my text files.
I just don't know what step 1 was asking me for the prcess, and so I wasn't able to simulate the log (was I supposed to plot down one of the given circuits and connect it to mine, or was I supposed to plug mine to yours?)
Conclusion: I believe my logic is right for my circuit, but I have no way to test it! I can show you my truth tables during office hours however!
